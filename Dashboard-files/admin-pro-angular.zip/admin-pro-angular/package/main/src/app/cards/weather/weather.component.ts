import { Component } from '@angular/core';

@Component({
  templateUrl: 'weather.component.html'
})
export class WeatherComponent {}
